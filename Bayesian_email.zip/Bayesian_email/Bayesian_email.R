library(tm)
library(stringr)
library(SnowballC)
library(gmodels)

# trian 데이터 불러오기

smsraw <- read.csv("sms_spam_ansi.txt")
str(smsraw)
smsraw$type <- factor(smsraw$type)
table(smsraw$type)

smsCorpus <- VCorpus(VectorSource(smsraw$text))
lapply(smsCorpus[1:3], as.character)

# $`1`
# [1] "Hope you are having a good week. Just checking in"
# $`2`
# [1] "K..give back my thanks."
# $`3`
# [1] "Am also doing in cbe only. But have to pay."



# 데이터 전처리

# 1. 대문자 -> 소문자로 통일

smsCorpusClean <- tm_map(smsCorpus, content_transformer(tolower))
lapply(smsCorpusClean[1:3], as.character)

# $`1`
# [1] "hope you are having a good week. just checking in"
# $`2`
# [1] "k..give back my thanks."
# $`3`
# [1] "am also doing in cbe only. but have to pay."


# 2. 숫자 제거

smsCorpusClean <- tm_map(smsCorpusClean, removeNumbers)
lapply(smsCorpusClean[1:3], as.character)

# $`1`
# [1] "hope you are having a good week. just checking in"
# $`2`
# [1] "k..give back my thanks."
# $`3`
# [1] "am also doing in cbe only. but have to pay."


# 3. 불용어 제거

smsCorpusClean <- tm_map(smsCorpusClean, removeWords, stopwords())
lapply(smsCorpusClean[1:3], as.character)

# $`1`
# [1] "hope     good week. just checking "
# $`2`
# [1] "k..give back  thanks."
# $`3`
# [1] " also   cbe .    pay."


# 4. 구두점 제거

remPunct <- function(x){
  gsub("[[:punct:]]+", " ", x)
}

smsCorpusClean <- tm_map(smsCorpusClean, content_transformer(remPunct))
lapply(smsCorpusClean[1:3], as.character)

# $`1`
# [1] "hope     good week  just checking "
# $`2`
# [1] "k give back  thanks "
# $`3`
# [1] " also   cbe      pay "


# 5. 단어 길이가 2 미만인 단어는 제거

smsCorpusClean <- tm_map(smsCorpusClean, removeWords, "[[:alpha:]]{1}")
lapply(smsCorpusClean[1:4], as.character)

# $`1`
# [1] "hope     good week  just checking "
# $`2`
# [1] " give back  thanks "
# $`3`
# [1] " also   cbe      pay "
# $`4`
# [1] "complimentary  star ibiza holiday  ￡  cash needs  urgent collection   now  landline   lose   boxskwpppm "


# 6. word stemming

smsCorpusClean <- tm_map(smsCorpusClean, stemDocument)
lapply(smsCorpusClean[1:4], as.character)

# $`1`
# [1] "hope good week just check"
# $`2`
# [1] "give back thank"
# $`3`
# [1] "also cbe pay"
# $`4`
# [1] "complimentari star ibiza holiday ￡ cash need urgent collect now landlin lose boxskwpppm"


# 7. ￡ 제거

rempunct <- function(x){
  str_replace_all(x, "[[:space:]]{1}￡[[:space:]]{1}", " ")
}
smsCorpusClean <- tm_map(smsCorpusClean, content_transformer(rempunct))
lapply(smsCorpusClean[1:4], as.character)

# $`1`
# [1] "hope good week just check"
# $`2`
# [1] "give back thank"
# $`3`
# [1] "also cbe pay"
# $`4`
# [1] "complimentari star ibiza holiday cash need urgent collect now landlin lose boxskwpppm"

# 8. space 정리

smsCorpusClean <- tm_map(smsCorpusClean, stripWhitespace)
lapply(smsCorpusClean[1:4], as.character)

# $`1`
# [1] "hope good week just check"
# $`2`
# [1] "give back thank"
# $`3`
# [1] "also cbe pay"
# $`4`
# [1] "complimentari star ibiza holiday cash need urgent collect now landlin lose boxskwpppm"



# Dtm

smsDtm <- DocumentTermMatrix(smsCorpusClean)
smsDtm   #documents: 5559, terms: 6094


# train 데이터와 test 데이터 생성

set.seed(0317)
5559*0.3  #1667.7
te_idx <- sample(1:5559, 1668)
smsDtmTrain <- smsDtm[-te_idx,]
smsDtmTest <- smsDtm[te_idx,]

smsTrainLabels <- smsraw[-te_idx,]$type
smsTestLabels <- smsraw[te_idx,]$type

prop.table(table(smsTrainLabels))
prop.table(table(smsTestLabels))




# findFreqTerms 함수에서 최소 등장 횟수를 변경하여 
# 5보다 더 작은 값으로 수정 -> 정확도 비교


# 전처리 과정을 추가하여 terms가 6094로 줄었으므로 
# 5일 때부터 다시 진행하여 비교해보도록 했다.

smsDtmTrain   #terms: 6094, Sparsity: 100%

# 경우1. lowfreq = 5

smsFreqWords <- findFreqTerms(smsDtmTrain, 5)
str(smsFreqWords)

smsDtmFreqTrain <- smsDtmTrain[,smsFreqWords]
smsDtmFreqTrain  #3891*1103, Sparsity: 99%
smsDtmFreqTest <- smsDtmTest[,smsFreqWords]
smsDtmFreqTest  #1668*1103, Sparsity: 99%


# 1137개 단어 각각에 대해
# 등장한 경우와 등장하지 않은 경우로 구분

convertCounts <- function(x){
  ifelse(x>0, "Yes", "No")
}

smsTrain <- apply(smsDtmFreqTrain, 2, convertCounts)
str(smsTrain)
smsTrain[1]  #No
smsTest <- apply(smsDtmFreqTest, 2, convertCounts)
str(smsTest)
smsTest[1]  #No


# 나이브베이즈 모델 생성 -> 테스트 데이터 넣어서 결과비교

smsClass <- naiveBayes(smsTrain, smsTrainLabels, laplace = 1)

smsTestPred <- predict(smsClass, smsTest)

CrossTable(smsTestPred, smsTestLabels)  #오답 32개



# 경우2. lowfreq = 4

smsFreqWords <- findFreqTerms(smsDtmTrain, 4)
str(smsFreqWords)

smsDtmFreqTrain <- smsDtmTrain[,smsFreqWords]
smsDtmFreqTrain  #3891*1364, Sparsity: 100%
smsDtmFreqTest <- smsDtmTest[,smsFreqWords]
smsDtmFreqTest  #1668*1364, Sparsity: 100%


# 1364개 단어 각각에 대해
# 등장한 경우와 등장하지 않은 경우로 구분

smsTrain <- apply(smsDtmFreqTrain, 2, convertCounts)
str(smsTrain)
smsTrain[1]  #No
smsTest <- apply(smsDtmFreqTest, 2, convertCounts)
str(smsTest)
smsTest[1]  #No


# 나이브베이즈 모델 생성 -> 테스트 데이터 넣어서 결과비교

smsClass <- naiveBayes(smsTrain, smsTrainLabels, laplace = 1)

smsTestPred <- predict(smsClass, smsTest)

CrossTable(smsTestPred, smsTestLabels)  #오답 27개




# 경우3. lowfreq = 3

smsFreqWords <- findFreqTerms(smsDtmTrain, 3)
str(smsFreqWords)

smsDtmFreqTrain <- smsDtmTrain[,smsFreqWords]
smsDtmFreqTrain  #3891*1735, Sparsity: 100%
smsDtmFreqTest <- smsDtmTest[,smsFreqWords]
smsDtmFreqTest  #1668*1735, Sparsity: 100%


# 1735개 단어 각각에 대해
# 등장한 경우와 등장하지 않은 경우로 구분

smsTrain <- apply(smsDtmFreqTrain, 2, convertCounts)
str(smsTrain)
smsTrain[1]  #No
smsTest <- apply(smsDtmFreqTest, 2, convertCounts)
str(smsTest)
smsTest[1]  #No


# 나이브베이즈 모델 생성 -> 테스트 데이터 넣어서 결과비교

smsClass <- naiveBayes(smsTrain, smsTrainLabels, laplace = 1)

smsTestPred <- predict(smsClass, smsTest)

CrossTable(smsTestPred, smsTestLabels)  #오답 42개




# 경우4. lowfreq = 2

smsFreqWords <- findFreqTerms(smsDtmTrain, 2)
str(smsFreqWords)

smsDtmFreqTrain <- smsDtmTrain[,smsFreqWords]
smsDtmFreqTrain  #3891*2480, Sparsity: 100%
smsDtmFreqTest <- smsDtmTest[,smsFreqWords]
smsDtmFreqTest  #1668*2480, Sparsity: 100%


# 2480개 단어 각각에 대해
# 등장한 경우와 등장하지 않은 경우로 구분

smsTrain <- apply(smsDtmFreqTrain, 2, convertCounts)
str(smsTrain)
smsTrain[1]  #No
smsTest <- apply(smsDtmFreqTest, 2, convertCounts)
str(smsTest)
smsTest[1]  #No


# 나이브베이즈 모델 생성 -> 테스트 데이터 넣어서 결과비교

smsClass <- naiveBayes(smsTrain, smsTrainLabels, laplace = 1)

smsTestPred <- predict(smsClass, smsTest)

CrossTable(smsTestPred, smsTestLabels)  #오답 80개


## 최적의 lowfreq는 4이다.
## (1까지 하는 것은 의미 없을 것 같아 진행하지 않았다)


#################################################################


# 이제 실제로 판단하고자 하는 파일(email_title.txt)을 처리해보자.

# 데이터 불러오기

examraw <- read.csv("email_title.txt", header = F, encoding = "UTF-8")
str(examraw)

colnames(examraw) <- c("type","text")
str(examraw)

examraw$type <- factor(examraw$type)
table(examraw$type)

examCorpus <- VCorpus(VectorSource(examraw$text))
lapply(examCorpus[6:8], as.character)

# $`6`
# [1] "K so am I, how much for an 8th? Fifty?"
# $`7`
# [1] "K, wat s tht incident?"
# $`8`
# [1] "S now only i took tablets . Reaction morning only."


# 데이터 전처리

# 1. 대문자 -> 소문자로 통일

examCorpusClean <- tm_map(examCorpus, content_transformer(tolower))
lapply(examCorpusClean[6:8], as.character)

# $`6`
# [1] "k so am i, how much for an 8th? fifty?"
# $`7`
# [1] "k, wat s tht incident?"
# $`8`
# [1] "s now only i took tablets . reaction morning only."


# 2. 숫자 제거

examCorpusClean <- tm_map(examCorpusClean, removeNumbers)
lapply(examCorpusClean[6:8], as.character)

# $`6`
# [1] "k so am i, how much for an th? fifty?"
# $`7`
# [1] "k, wat s tht incident?"
# $`8`
# [1] "s now only i took tablets . reaction morning only."


# 3. 불용어 제거

examCorpusClean <- tm_map(examCorpusClean, removeWords, stopwords())
lapply(examCorpusClean[6:8], as.character)

# $`6`
# [1] "k      much   th  fifty "
# $`7`
# [1] "k  wat s tht incident "
# $`8`
# [1] "s now   took tablets   reaction morning  "


# 4. 구두점 제거

# 위의 train 데이터 전처리에서 만들었던 remPunct 함수를 사용했다

remPunct <- function(x){
  gsub("[[:punct:]]+", " ", x)
}
examCorpusClean <- tm_map(examCorpusClean, content_transformer(remPunct))
lapply(examCorpusClean[6:8], as.character)

# $`6`
# [1] "k      much   th  fifty "
# $`7`
# [1] "k  wat s tht incident "
# $`8`
# [1] "s now   took tablets   reaction morning  "


# 5. 단어 길이가 2 미만인 단어는 제거

examCorpusClean <- tm_map(examCorpusClean, removeWords, "[[:alpha:]]{1}")
lapply(examCorpusClean[6:8], as.character)

# $`6`
# [1] "      much   th  fifty "
# $`7`
# [1] "  wat  tht incident "
# $`8`
# [1] " now   took tablets   reaction morning  "


# 6. word stemming

examCorpusClean <- tm_map(examCorpusClean, stemDocument)
lapply(examCorpusClean[6:8], as.character)

# $`6`
# [1] "much th fifti"
# $`7`
# [1] "wat tht incid"
# $`8`
# [1] "now took tablet reaction morn"


# 7. ￡ 제거

# train 데이터 전처리에서 사용했던 rempunct 함수 사용했다
rempunct <- function(x){
  str_replace_all(x, "[[:space:]]{1}￡[[:space:]]{1}", " ")
}
examCorpusClean <- tm_map(examCorpusClean, content_transformer(rempunct))
lapply(examCorpusClean[6:8], as.character)

# $`6`
# [1] "much th fifti"
# $`7`
# [1] "wat tht incid"
# $`8`
# [1] "now took tablet reaction morn"


# 8. space 정리

examCorpusClean <- tm_map(examCorpusClean, stripWhitespace)
lapply(examCorpusClean[6:8], as.character)

# $`6`
# [1] "much th fifti"
# $`7`
# [1] "wat tht incid"
# $`8`
# [1] "now took tablet reaction morn"


# Dtm

examDtm <- DocumentTermMatrix(examCorpusClean)
examDtm   #documents: 22, terms: 139, Sparsity: 95%

examLabels <- examraw$type
examLabels


# 미리 생성해둔 나이브 베이즈 모델에 넣기
# exam데이터는 22개밖에 없어서 findFreqTerms를 진행하지 않았다

# 1364개 단어 각각에 대해
# 등장한 경우와 등장하지 않은 경우로 구분

exam <- apply(examDtm, 2, convertCounts)
str(exam)
exam[1]  #No

examPred <- predict(smsClass, exam)

# 정확도

CrossTable(examPred, examLabels)  #오답 4개

sum(examPred == examLabels) / length(examLabels)  #0.8181818
